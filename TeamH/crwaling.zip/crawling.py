from matplotlib.pyplot import table
import requests
from bs4 import BeautifulSoup
from traceback import print_list
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import time
import re
import json
import csv
 

headers ={
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36",
    "Accept-Language":"ko-KR,ko"
    }
url = "https://ur1004.skku.edu/ur1004/program/registration.do?mode=list&&articleLimit=10&article.offset=0"
res = requests.get(url,headers=headers)#
res.raise_for_status()
soup =BeautifulSoup(res.text,"lxml")
soup.prettify
tables = soup.find("tbody")


words=[]
f = open('data.csv','w',encoding="utf8",newline='')
wr = csv.writer(f)
wr.writerow(["title","category","contents","link"])


for table in tables.get_text().split():
    if(table!="\n"):
        words.append(table)

start = int(words[0])
wr.writerow(["헌혈도 앱으로 하는 시대 레드 커넥트","봉사","가까운 헌혈의집 확인부터 예약까지!","https://play.google.com/store/apps/details?id=com.sk.redconnect"])
row =["성균관대학교 UR1004 봉사활동","봉사","","https://ur1004.skku.edu/ur1004/program/registration.do?mode=list&&articleLimit=10&article.offset=0"]


i=0
for w in words:
    if(w==str(start-1)):
        wr.writerow(row)
        row =["성균관대학교 UR1004 봉사활동","봉사","","https://ur1004.skku.edu/ur1004/program/registration.do?mode=list&&articleLimit=10&article.offset=0"]
        start-=1
        i=0
    if (i==0):
        i+=1
    row[2]=row[2]+w+" "
wr.writerow(row)
#######################################################################################incurte

url = "https://job.incruit.com/entry/searchjob.asp?jobty=4&scale=3&group1=3&schol=70&schol=60&occ1=150"
res = requests.get(url,headers=headers)#
res.raise_for_status()
soup =BeautifulSoup(res.text,"lxml")
soup.prettify


tables = soup.find("div",attrs={"class":"cBbslist_contenst"})
words=[]

for table in tables.get_text().split():
    if(table!="\n"):
        words.append(table)
# print(words)



row =["","기업인턴십/산학협력","","https://job.incruit.com/entry/searchjob.asp?jobty=4&scale=3&group1=3&schol=70&schol=60&occ1=150"]
sentence=""

i=0
for w in words:
    # 날짜나오면 끝 + i=0이면 시작
    # 관심기업, 스크랩, 공채자료, 채용시, 자소서, 작성

    if(i==0):
        row[0]=w
        sentence+=w+" "
        i=1
        continue

    if((w=='취업자료')|(w=='바로지원')&(i!=-1)):
        i=-1
        continue
    if((w=='취업자료')|(w=='바로지원')):
        continue
    if(i==-1):
        i=1
        row[2]=sentence
        sentence=w+" "
        wr.writerow(row)
        row =["","기업인턴십/산학협력","","https://job.incruit.com/entry/searchjob.asp?jobty=4&scale=3&group1=3&schol=70&schol=60&occ1=150"]
        row[0]=w
        
    if((w!='관심기업')&(w!='스크랩')&(w!='공채자료')&(w!='채용시')&(w!='자소서')& (w!='작성')&(w!='취업자료')&(w!='바로지원')):
        sentence+=w+" "
    
#######################################################################################saramin

url = "https://www.saramin.co.kr/zf_user/jobs/public/list?sort=ud&quick_apply=&show_applied=&search_day=&keyword=&pr_exp_lv%5B%5D=1&final_edu%5B%5D=3&company_scale%5B%5D=1&company_scale%5B%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=1#listTop%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=4#listTop"
res = requests.get(url,headers=headers)#
res.raise_for_status()
soup =BeautifulSoup(res.text,"lxml")
soup.prettify



tables = soup.find("table")
words=[]
for table in tables.get_text().split():
    if(table!="\n"):
        words.append(table)



row =["","기업인턴십/산학협력","","https://www.saramin.co.kr/zf_user/jobs/public/list?sort=ud&quick_apply=&show_applied=&search_day=&keyword=&pr_exp_lv%5B%5D=1&final_edu%5B%5D=3&company_scale%5B%5D=1&company_scale%5B%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=1#listTop%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=4#listTop"]
row1 =["","취업캠프/서류,면접 클리닉","","https://www.saramin.co.kr/zf_user/jobs/public/list?sort=ud&quick_apply=&show_applied=&search_day=&keyword=&pr_exp_lv%5B%5D=1&final_edu%5B%5D=3&company_scale%5B%5D=1&company_scale%5B%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=1#listTop%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=4#listTop"]

sentence=""

i=1
for w in words:
    # 선택이 시작 (주)는 거를것
    # 관심기업, 스크랩, 공채자료, 채용시, 자소서작성,

    if((w=='관심기업')|(w=='스크랩')|(w=='공채자료')|(w=='채용시')|(w=='취업자료')|(w=='바로지원')|(w=='선택')|(w=='(주)')):
        continue
    elif(w!='자소서작성'):
        sentence+=w+" "
    
    if(i==1):
        
        row[0]=w
        row1[0]=w
        i=2
        continue
    if(w=='자소서작성'):
        i=1
        row[2]=sentence
        row1[2]=sentence
        sentence=""
        wr.writerow(row)
        wr.writerow(row1)
        
        row =["","기업인턴십/산학협력","","https://www.saramin.co.kr/zf_user/jobs/public/list?sort=ud&quick_apply=&show_applied=&search_day=&keyword=&pr_exp_lv%5B%5D=1&final_edu%5B%5D=3&company_scale%5B%5D=1&company_scale%5B%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=1#listTop%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=4#listTop"]
        row1=["","취업캠프/서류,면접 클리닉","","https://www.saramin.co.kr/zf_user/jobs/public/list?sort=ud&quick_apply=&show_applied=&search_day=&keyword=&pr_exp_lv%5B%5D=1&final_edu%5B%5D=3&company_scale%5B%5D=1&company_scale%5B%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=1#listTop%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=4#listTop"]

        
    
#######################################################################################incurte
url = "https://job.incruit.com/entry/searchjob.asp?jobty=1&scale=3&group1=3&schol=70&schol=60&occ1=150"
res = requests.get(url,headers=headers)#
res.raise_for_status()
soup =BeautifulSoup(res.text,"lxml")
soup.prettify

tables = soup.find("div",attrs={"class":"cBbslist_contenst"})
words=[]

for table in tables.get_text().split():
    if(table!="\n"):
        words.append(table)
# print(words)



row =["","취업캠프/서류,면접 클리닉","","https://job.incruit.com/entry/searchjob.asp?jobty=1&scale=3&group1=3&schol=70&schol=60&occ1=150"]
sentence=""

i=0
for w in words:
    # 날짜나오면 끝 + i=0이면 시작
    # 관심기업, 스크랩, 공채자료, 채용시, 자소서, 작성

    if(i==0):
        row[0]=w
        sentence+=w+" "
        i=1
        continue

    if((w=='취업자료')|(w=='바로지원')&(i!=-1)):
        i=-1
        continue
    if((w=='취업자료')|(w=='바로지원')):
        continue
    if(i==-1):
        i=1
        row[2]=sentence
        sentence=w+" "
        wr.writerow(row)
        row =["","취업캠프/서류,면접 클리닉","","https://job.incruit.com/entry/searchjob.asp?jobty=1&scale=3&group1=3&schol=70&schol=60&occ1=150"]
        row[0]=w
        
    if((w!='관심기업')&(w!='스크랩')&(w!='공채자료')&(w!='채용시')&(w!='자소서')& (w!='작성')&(w!='취업자료')&(w!='바로지원')):
        sentence+=w+" "
          
#######################################################################################jobkorea0

url = "https://www.jobkorea.co.kr/starter/?chkSubmit=1&schCareer=1&schLocal=I000,B000,K000&schPart=10016&schMajor=&schEduLevel=5,6&schWork=2&schCType=11,12,13&isSaved=1&LinkGubun=0&LinkNo=0&Page=1&schType=0&schGid=0&schOrderBy=0&schTxt="
res = requests.get(url,headers=headers)#
res.raise_for_status()
soup =BeautifulSoup(res.text,"lxml")
soup.prettify



tables = soup.find("ul",attrs={"class":"filterList"})
words=[]

for table in tables.get_text().split():
    if(table!="\n"):
        words.append(table)




row =["","기업인턴십/산학협력","","https://www.jobkorea.co.kr/starter/?chkSubmit=1&schCareer=1&schLocal=I000,B000,K000&schPart=10016&schMajor=&schEduLevel=5,6&schWork=2,3&schCType=11,12,13&isSaved=1&LinkGubun=0&LinkNo=0&Page=1&schType=0&schGid=0&schOrderBy=0&schTxt="]
sentence=""

i=0
for w in words:
    # 날짜나오면 끝 + i=0이면 시작
    # 관심기업, 스크랩, 공채자료, 채용시, 자소서, 작성

    if(i==0):
        row[0]=w
        i=1
        continue

    if((w!='관심기업')&(w!='스크랩')&(w!='공채자료')&(w!='채용시')&(w!='자소서')& (w!='작성')):
        sentence+=w+" "
    
    if(w[0]=='~'):
        i=0
        row[2]=sentence
        sentence=""
        wr.writerow(row)
        row =["","기업인턴십/산학협력","","https://www.jobkorea.co.kr/starter/?chkSubmit=1&schCareer=1&schLocal=I000,B000,K000&schPart=10016&schMajor=&schEduLevel=5,6&schWork=2,3&schCType=11,12,13&isSaved=1&LinkGubun=0&LinkNo=0&Page=1&schType=0&schGid=0&schOrderBy=0&schTxt="]
        continue
    


#######################################################################################jobkorea1
url = "https://www.jobkorea.co.kr/starter/?chkSubmit=1&schCareer=1&schLocal=I000,B000,K000&schPart=10016&schMajor=&schEduLevel=5,6&schWork=1&schCType=11,12,13&isSaved=1&LinkGubun=0&LinkNo=0&Page=1&schType=0&schGid=0&schOrderBy=0&schTxt="
res = requests.get(url,headers=headers)#
res.raise_for_status()
soup =BeautifulSoup(res.text,"lxml")
soup.prettify



tables = soup.find("ul",attrs={"class":"filterList"})
words=[]

for table in tables.get_text().split():
    if(table!="\n"):
        words.append(table)




row =["","취업캠프/서류,면접 클리닉","","https://www.jobkorea.co.kr/starter/?chkSubmit=1&schCareer=1&schLocal=I000,B000,K000&schPart=10016&schMajor=&schEduLevel=5,6&schWork=1&schCType=11,12,13&isSaved=1&LinkGubun=0&LinkNo=0&Page=1&schType=0&schGid=0&schOrderBy=0&schTxt="]
sentence=""

i=0
for w in words:
    # 날짜나오면 끝 + i=0이면 시작
    # 관심기업, 스크랩, 공채자료, 채용시, 자소서, 작성

    if(i==0):
        row[0]=w
        i=1
        continue

    if((w!='관심기업')&(w!='스크랩')&(w!='공채자료')&(w!='채용시')&(w!='자소서')& (w!='작성')):
        sentence+=w+" "
    
    if(w[0]=='~'):
        i=0
        row[2]=sentence
        sentence=""
        wr.writerow(row)
        row =["","취업캠프/서류,면접 클리닉","","https://www.jobkorea.co.kr/starter/?chkSubmit=1&schCareer=1&schLocal=I000,B000,K000&schPart=10016&schMajor=&schEduLevel=5,6&schWork=1&schCType=11,12,13&isSaved=1&LinkGubun=0&LinkNo=0&Page=1&schType=0&schGid=0&schOrderBy=0&schTxt="]
        continue
    

#######################################################################################vms
url = "https://www.vms.or.kr/partspace/recruit.do?area=0108&areagugun=4111000000&acttype=&status=1&volacttype=&sttdte=2022-11-12&enddte=2022-12-12&termgbn=&searchType=title&searchValue=&page=1"
res = requests.get(url,headers=headers)#
res.raise_for_status()
soup =BeautifulSoup(res.text,"lxml")
soup.prettify

tables = soup.find("div",attrs={"class":"boardList boardListService"})
words=[]


for table in tables.get_text().split():
    if(table!="\n"):
        words.append(table)
# print(words)



row =["vms 수원시 봉사활동","봉사","","https://www.vms.or.kr/partspace/recruit.do?area=0108&areagugun=4111000000&acttype=&status=1&volacttype=&sttdte=2022-11-12&enddte=2022-12-12&termgbn=&searchType=title&searchValue=&page=1"]
sentence=""

i=0
for w in words:
    
    if(w=="필요/신청인원:"):
        row[0]=sentence
    if(i==-1):
        i=-2
        continue
    if(w=="[모집중]"):
        sentence=""
        i=-1
    if(i==-2):
        sentence=sentence+w+" "
    if(w=='모집기관:'):
        i=-3
        continue
    if(i==-3):
        sentence=sentence+w+" "
        row[2]=sentence
        wr.writerow(row)
        sentence=""
        i=0
        row =["vms 수원시 봉사활동","봉사","","https://www.vms.or.kr/partspace/recruit.do?area=0108&areagugun=4111000000&acttype=&status=1&volacttype=&sttdte=2022-11-12&enddte=2022-12-12&termgbn=&searchType=title&searchValue=&page=1"]




###########################################################################################



url = "https://ur1004.skku.edu/ur1004/community/notice.do"
res = requests.get(url,headers=headers)#
res.raise_for_status()
soup =BeautifulSoup(res.text,"lxml")
soup.prettify

tables = soup.find("ul",attrs={"class":"board-list-wrap"})

words=[]

for table in tables.get_text().split():
    if(table!="\n"):
        words.append(table)


# start = int(words[0])
row =["성균관대학교 UR1004 봉사활동 프로그램","봉사","","https://ur1004.skku.edu/ur1004/community/notice.do"]

i=0
for w in words:
    if(w=='ur1004'):
        i=4
        continue
    if (i==0):
        
        i=100
    elif((i==1)&(w!='첨부파일')):
        wr.writerow(row)
        row =["성균관대학교 UR1004 봉사활동 프로그램","봉사","","https://ur1004.skku.edu/ur1004/community/notice.do"]

        i=100
    elif((i==1)&(w=='첨부파일')):
        i=0
        continue
    row[2]=row[2]+w+" "
    i-=1
    


    
    
wr.writerow(row)       

# ##########################################################################################################


options = webdriver.ChromeOptions()
options.add_experimental_option("excludeSwitches", ["enable-logging"])
browser = webdriver.Chrome(options=options)
browser.get('https://www.1365.go.kr/vols/1572247904127/partcptn/timeCptn.do') 
time.sleep(1)

browser.find_element(By.XPATH,"/html/body/div[2]/div[2]/div[2]/div[2]/div[2]/form/div[1]/div/table/tbody/tr/td[1]/div/select/option[10]").click()
time.sleep(1)
browser.find_element(By.XPATH,"/html/body/div[2]/div[2]/div[2]/div[2]/div[2]/form/div[1]/div/table/tbody/tr/td[2]/div/select/option[2]").click()

time.sleep(3)
browser.find_element(By.XPATH,"/html/body/div[2]/div[2]/div[2]/div[2]/div[2]/form/div[2]/div/div/button[1]/span").click()
time.sleep(10)


# table 가져오기

elements = browser.find_elements(By.XPATH, "/html/body/div[2]/div[2]/div[2]/div[2]/div[2]/div[4]/ul")
elem = elements[0].text.splitlines()
i=0
words=""
row =["title","봉사","c","https://www.1365.go.kr/vols/1572247904127/partcptn/timeCptn.do"]

for e in elem:
    if(i%9==0):
        row[0]=e
        words=words+" "+e
    if(i%9==1):
        row[0]=row[0]+e
        words=words+" "+e
    if((i%9==7)&(i!=88)):
        words+=words
        row[2]=words
        wr.writerow(row)
        words=""
    i+=1
    if(i==88):
        words+=words
        row[2]=words
        wr.writerow(row)
        


# wr.writerow('{"title":"취업 전문 사이트 사람인 IT 인턴십 + 정규직 바로가기","category":"기업인턴십/산학협력","contents":"취업전문 사이트 사람인에 올라온 정보를 바로 확인하세요!","link":"https://www.saramin.co.kr/zf_user/jobs/public/list?sort=ud&quick_apply=&show_applied=&search_day=&keyword=&pr_exp_lv%5B%5D=1&final_edu%5B%5D=3&company_scale%5B%5D=1&company_scale%5B%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=1#listTop%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=4#listTop"}]\n')

browser.close()


options = webdriver.ChromeOptions()
options.add_experimental_option("excludeSwitches", ["enable-logging"])
browser0 = webdriver.Chrome(options=options)
browser0.get('https://cs.skku.edu/ko/news/recruit/list') 

row =["","취업캠프/서류,면접 클리닉","","https://cs.skku.edu/ko/news/recruit/list"]

new_str=""
elements = browser0.find_elements(By.TAG_NAME, "td")
for i,e in enumerate(elements):
    new_str=new_str+e.text+" "
    if((i+1)%5==2):
        row[0]=e.text
        
    if((i+1)%5==0):
        row[2]=new_str
        new_str=""
        wr.writerow(row)
        row =["","취업캠프/서류,면접 클리닉","","https://cs.skku.edu/ko/news/recruit/list"]

browser0.close()


####################################################################################### new combine

time.sleep(3)
browser1 = webdriver.Chrome(options=options)
browser1.get('https://chsquare.skku.edu/challenge/nxui/index.html?ticket=dZvGDG1D4p3CHoZG') 
#로그인
WebDriverWait(browser1,10).until(EC.presence_of_element_located((By.XPATH,"/html/body/div/div[1]/div/div/div[1]/div/div/div/div[1]/div/div[2]/div/div[1]/div/div[1]/input")))
browser1.find_element(By.XPATH,"/html/body/div/div[1]/div/div/div[1]/div/div/div/div[1]/div/div[2]/div/div[1]/div/div[1]/input").send_keys("rkdtlsrb")
browser1.find_element(By.XPATH,"/html/body/div/div[1]/div/div/div[1]/div/div/div/div[1]/div/div[2]/div/div[1]/div/div[2]/input").click()
browser1.find_element(By.XPATH,"/html/body/div/div[1]/div/div/div[1]/div/div/div/div[1]/div/div[2]/div/div[1]/div/div[2]/input").send_keys("as156423!!")
browser1.find_element(By.XPATH,"/html/body/div/div[1]/div/div/div[1]/div/div/div/div[1]/div/div[2]/div/div[1]/div/div[3]/div").click()
time.sleep(10)


browser1.find_element(By.XPATH,"/html/body/div/div[2]/div/div[1]/div/div[1]/div/div[4]").click()

#로딩 기다리기


import time
time.sleep(40)
#팝업닫기

time.sleep(5)
elem2= browser1.find_element(By.XPATH,"/html/body/div/div[2]/div/div[2]/div/div[5]").click()
    

#비교과 찾아가기
e3 = browser1.find_element(By.XPATH,"/html/body/div/div[1]/div/div/div[1]/div/div/div/div/div/div[1]/div/div/div/div[2]/div/div/div/div[18]").click()
e4 = browser1.find_element(By.XPATH,"/html/body/div/div[3]/div/div[3]/div/div[1]/div/div/div/div[1]/div/div/div/div[4]").click()
time.sleep(1)




new_str=""
e5 = browser1.find_elements(By.XPATH,"/html/body/div/div[1]/div/div/div[1]/div/div/div/div/div/div[3]/div/div[1]/div/div[2]/div/div[1]/div/div/div/div[3]/div/div[3]/div[1]/div[2]/div/div")
row =["","취업캠프/서류,면접 클리닉","","https://chsquare.skku.edu/challenge/nxui/index.html?ticket=dZvGDG1D4p3CHoZG"]
e6 = e5[0].text.splitlines()
start=0
i=0
for e in e6:
    if((e=='2022')&(str(start)=='0')):
        new_str=""
        new_str=new_str+e+" "
        i+=1
    elif(((i+1)%9==3)&(start==0)):
        row[0]=e
        start='1'
        new_str=new_str+e+" "
        i+=1
    elif((e=='2022')&(str(start)=='1')):
        row[2]=new_str
        wr.writerow(row)
        new_str=""
        new_str=new_str+e+" "
        row =["","취업캠프/서류,면접 클리닉","","https://chsquare.skku.edu/challenge/nxui/index.html?ticket=dZvGDG1D4p3CHoZG"]
        i=0
    elif((i==1)&(start!=0)):
        row[0]=e
        
        new_str=new_str+e+" "
        i+=1
    else:
        new_str=new_str+e+" "
        i+=1

row[2]=new_str
wr.writerow(row)
row =["","취업캠프/서류,면접 클리닉","","https://chsquare.skku.edu/challenge/nxui/index.html?ticket=dZvGDG1D4p3CHoZG"]

browser1.close()
################################################################################


time.sleep(3)
browser2 = webdriver.Chrome(options=options)
browser2.get('https://tollgate.skku.edu/') 
#browser2.maximize_window()
#로그인

browser2.find_element(By.XPATH,"/html/body/div[2]/div[3]/div/button[2]").click()
WebDriverWait(browser2,10).until(EC.presence_of_element_located((By.XPATH,"/html/body/div/div[2]/div[2]/div[2]/div/div[1]/div/span[1]/input[1]")))
browser2.find_element(By.XPATH,"/html/body/div/div[2]/div[2]/div[2]/div/div[1]/div/span[1]/input[1]").click()
WebDriverWait(browser2,10).until(EC.element_to_be_clickable((By.XPATH,"/html/body/div/div/form/div/div[2]/input")))
time.sleep(5)
browser2.find_element(By.XPATH,"/html/body/div/div/form/div/div[2]/input").click()
browser2.find_element(By.XPATH,"/html/body/div/div/form/div/div[2]/input").send_keys("rkdtlsrb")
browser2.find_element(By.XPATH,"/html/body/div/div/form/div/div[4]/input").click()
browser2.find_element(By.XPATH,"/html/body/div/div/form/div/div[4]/input").send_keys("as156423!!")
time.sleep(5)
browser2.find_element(By.XPATH,"/html/body/div/div/form/div/div[5]/a/img").click()
#로딩 기다리기

browser2.find_element(By.XPATH,"/html/body/div[1]/div[1]/div[2]/ul[1]/li[7]/a").click()
time.sleep(1)
browser2.find_element(By.XPATH,"//*[@id='nav']/li[7]/ul/li/ul/li[2]").click()

# table 가져오기

elements = browser2.find_elements(By.XPATH, "/html/body/div[1]/div[2]/div/div[2]/div/table/tbody")
e7 = elements[0].text.splitlines()

row =["톨게이트 채용공고","취업캠프/서류,면접 클리닉","","https://tollgate.skku.edu/"]
for e in e7:
    row[2]=e
    wr.writerow(row)



# wr.writerow('{"title":"취업 전문 사이트 사람인 IT 인턴십 + 정규직 바로가기","category":"기업인턴십/산학협력","contents":"취업전문 사이트 사람인에 올라온 정보를 바로 확인하세요!","link":"https://www.saramin.co.kr/zf_user/jobs/public/list?sort=ud&quick_apply=&show_applied=&search_day=&keyword=&pr_exp_lv%5B%5D=1&final_edu%5B%5D=3&company_scale%5B%5D=1&company_scale%5B%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=1#listTop%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=4#listTop"}]\n')

browser2.close()

f.close()