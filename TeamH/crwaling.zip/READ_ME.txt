1. 성균관대학교 교내봉사 ur1004
2. 성균관대학교 교내봉사프로그램 공지사항 ur1004
3. 1365 수원 봉사활동 리스트
4. vms 수원 봉사활동리스트
5. 잡코리아 매출 1000대기업
6. 잡코리아 인턴 채용공고
7. 인크루트 신입 100대기업
8. 인크루트 인턴 채용공고
9. 사람인 정규 + 인턴 채용공고
10. 성균관대학교 소프트웨어대학 취업, 인턴십 공고
11. 챌린지스퀘어 비교과프로그램
12. 톨게이트 인턴/산학협력 모집공고


+
1. 헌혈앱 레드커넥트



=================

헌혈도 앱으로 레드커넥트
https://ur1004.skku.edu/ur1004/program/registration.do?mode=list&&articleLimit=10&article.offset=0
장기?
https://ur1004.skku.edu/ur1004/community/notice.do
1365
https://www.1365.go.kr/vols/main.do


vms
https://www.vms.or.kr/partspace/recruit.do?area=0108&areagugun=4111100000&acttype=&status=1&volacttype=&sttdte=2022-11-12&enddte=2022-12-12&termgbn=&searchType=title&searchValue=&page=1

잡코리아 매출 1000대기업
https://www.jobkorea.co.kr/starter/?chkSubmit=1&schCareer=1&schLocal=I000,B000,K000&schPart=10016&schMajor=&schEduLevel=5,6&schWork=1&schCType=11,12,13&isSaved=1&LinkGubun=0&LinkNo=0&Page=1&schType=0&schGid=0&schOrderBy=0&schTxt=
잡코리아 인턴
https://www.jobkorea.co.kr/starter/?chkSubmit=1&schCareer=1&schLocal=I000,B000,K000&schPart=10016&schMajor=&schEduLevel=5,6&schWork=2,3&schCType=11,12,13&isSaved=1&LinkGubun=0&LinkNo=0&Page=1&schType=0&schGid=0&schOrderBy=0&schTxt=
====================================



인크루트 신입 100대기업
https://job.incruit.com/entry/searchjob.asp?jobty=1&scale=3&group1=3&schol=70&schol=60&occ1=150
인크루트 인턴
https://job.incruit.com/entry/searchjob.asp?jobty=4&scale=3&group1=3&schol=70&schol=60&occ1=150


사람인 정규 + 인턴
https://www.saramin.co.kr/zf_user/jobs/public/list?sort=ud&quick_apply=&show_applied=&search_day=&keyword=&pr_exp_lv%5B%5D=1&final_edu%5B%5D=3&company_scale%5B%5D=1&company_scale%5B%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=1#listTop%5D=2&up_cd%5B%5D=3&jobtype%5B%5D=4#listTop

beautib






-=======================================


헌혈도 앱으로 레드커넥트
https://play.google.com/store/apps/details?id=com.sk.redconnect




